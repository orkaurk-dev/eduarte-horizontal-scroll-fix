const status = document.getElementById("status");
const toggle = document.getElementById("toggle");
const copyStatus = document.getElementById("copy-status");
const code = document.querySelector("#code code").textContent;

function showState(result) {
  if (!result?.supported) {
    status.textContent = "Open an Eduarte or Educus page first.";
    status.className = "status off";
    toggle.disabled = true;
    return;
  }
  status.textContent = result.enabled ? "Fix is ON for this tab" : "Fix is OFF for this tab";
  status.className = `status ${result.enabled ? "on" : "off"}`;
  toggle.textContent = result.enabled ? "Turn off fix" : "Turn on fix";
  toggle.disabled = false;
}

chrome.runtime.sendMessage({ type: "get-popup-state" }, showState);

toggle.addEventListener("click", () => {
  chrome.runtime.sendMessage({ type: "toggle-current-tab" }, showState);
});

document.getElementById("copy").addEventListener("click", async () => {
  await navigator.clipboard.writeText(code);
  copyStatus.textContent = "Copied. Paste it into the Eduarte Console.";
});
