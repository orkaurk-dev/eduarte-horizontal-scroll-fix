const TAB_KEY_PREFIX = "eduarteScrollFix:";
const FIX_CSS = `html, body { max-width:100% !important; overflow-x:auto !important; }
.content-wrapper, .js-scroll-wrapper, form, .tasks, .week-planning { max-width:100% !important; box-sizing:border-box !important; overflow-x:auto !important; }
button, input[type=submit], input[type=button] { flex-shrink:0; }`;

function keyFor(tabId) {
  return `${TAB_KEY_PREFIX}${tabId}`;
}

function isSupportedUrl(url) {
  try {
    const hostname = new URL(url).hostname;
    return hostname === "eduarte.nl" || hostname.endsWith(".eduarte.nl") ||
      hostname === "educus.nl" || hostname.endsWith(".educus.nl");
  } catch {
    return false;
  }
}

async function getEnabled(tabId) {
  const key = keyFor(tabId);
  const result = await chrome.storage.session.get(key);
  return result[key] === true;
}

async function setActionState(tabId, enabled) {
  await chrome.action.setBadgeText({ tabId, text: enabled ? "ON" : "OFF" });
  await chrome.action.setBadgeBackgroundColor({ tabId, color: enabled ? "#188038" : "#5f6368" });
  await chrome.action.setTitle({
    tabId,
    title: `Eduarte horizontal scroll: ${enabled ? "On" : "Off"}`
  });
}

// Programmatic injection is used instead of relying on a page message. This also
// works immediately after a reload, before Eduarte has finished rendering.
async function applyFix(tabId) {
  await chrome.scripting.insertCSS({
    target: { tabId },
    css: FIX_CSS,
    origin: "USER"
  });
}

async function removeFix(tabId) {
  await chrome.scripting.removeCSS({
    target: { tabId },
    css: FIX_CSS,
    origin: "USER"
  });
}

chrome.action.onClicked.addListener(async (tab) => {
  if (!tab.id || !isSupportedUrl(tab.url)) return;

  const enabled = !(await getEnabled(tab.id));
  await chrome.storage.session.set({ [keyFor(tab.id)]: enabled });
  await setActionState(tab.id, enabled);
  await (enabled ? applyFix(tab.id) : removeFix(tab.id)).catch(() => {});
});

chrome.tabs.onActivated.addListener(async ({ tabId }) => {
  const tab = await chrome.tabs.get(tabId);
  if (isSupportedUrl(tab.url)) await setActionState(tabId, await getEnabled(tabId));
});

chrome.tabs.onUpdated.addListener(async (tabId, changeInfo, tab) => {
  if (changeInfo.status === "loading" && isSupportedUrl(tab.url)) {
    const enabled = await getEnabled(tabId);
    await setActionState(tabId, enabled);
    if (enabled) await applyFix(tabId).catch(() => {});
  }
});

chrome.tabs.onRemoved.addListener((tabId) => {
  chrome.storage.session.remove(keyFor(tabId));
});

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.type === "get-enabled" && sender.tab?.id) {
    getEnabled(sender.tab.id).then((enabled) => sendResponse({ enabled }));
    return true;
  }

  if (message.type === "get-popup-state" || message.type === "toggle-current-tab") {
    (async () => {
      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
      if (!tab?.id || !isSupportedUrl(tab.url)) {
        sendResponse({ supported: false });
        return;
      }

      let enabled = await getEnabled(tab.id);
      if (message.type === "toggle-current-tab") {
        enabled = !enabled;
        await chrome.storage.session.set({ [keyFor(tab.id)]: enabled });
        await (enabled ? applyFix(tab.id) : removeFix(tab.id));
      }
      await setActionState(tab.id, enabled);
      sendResponse({ supported: true, enabled });
    })().catch((error) => sendResponse({ supported: false, error: error.message }));
    return true;
  }
});
